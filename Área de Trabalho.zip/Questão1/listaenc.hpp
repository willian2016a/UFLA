#ifndef LISTAENC_HPP
#define LISTAENC_HPP

/** 
 * Declaração opaca da estrutura de uma lista.
 * 
 * Isso significa que os detalhes de implementação desta estrutura estão escondidos do usuário do TAD. 
 * A definição da estrutura ListaEnc encontra-se no arquivo \file ListaEnc.cpp.
 */
struct ListaEnc;

/** 
 * Declaração opaca da estrutura de um nó da lista.
 * 
 * Isso significa que os detalhes de implementação desta estrutura estão escondidos do usuário do TAD. 
 * A definição da estrutura Noh encontra-se no arquivo \file listaenc.cpp.
 */
struct Noh;

// Cria dinamicamente uma lista vazia e retorna o endereço onde ela se encontra alocada.
ListaEnc* criar_lista();

// Libera o espaço de memória anteriormente reservado para a lista.
void liberar_lista(ListaEnc* li);

// Verifica se a lista está vazia. 
bool estah_vazia(ListaEnc* li);

// Insere um novo elemento em uma posição pré-determinada da lista.  
void inserir(ListaEnc* li, int item, int pos);

// Remove e retorna o elemento de uma posição pré-determinada da lista. 
int remover(ListaEnc* li, int pos);

// Apenas retorna o elemento de uma posição pré-determinada da lista. 
int obter_elemento(ListaEnc* li, int pos);

// Retorna a quantidade de elementos da lista. 
int obter_tamanho(ListaEnc* li);

ListaEnc* clone(ListaEnc* li);

#endif
