#include <iostream>
#include "listaenc.hpp"

using namespace std;

int main(){
	ListaEnc* li = criar_lista();
	for(int i=0;i<5;i++){
		int num;
		cin>>num;
		inserir(li,num,i);
	}
	
	ListaEnc* Clo = criar_lista();
	Clo = clone(li);
	int ele = obter_elemento(Clo,3);
	cout<<ele;

	return 0;
}
