#include <iostream>
#include <string>
using namespace std;

struct Amigo{
	string nome;
	string data;
};

void ordenar(Amigo v[],int n){
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(v[j].nome[0] < v[i].nome[0]){
				string aux;
				aux = v[j].nome;
				v[j].nome = v[i].nome;
				v[i].nome = aux;
				
				aux = v[j].data;
				v[j].data = v[i].data;
				v[i].data = aux;
			}
		}	
	}
	cout<<"entrou";
}

int main(){
	int n;
	cin>>n;
	Amigo v[n];
	for(int k=0;k<n;k++){
		cin>>v[k].nome;
		cin>>v[k].data;
	}
	ordenar(v,n);
	for(int k=0;k<n;k++){
		cout<<v[k].nome<<" ";
		cout<<v[k].data;
		cout<<endl;
	}
	
}







