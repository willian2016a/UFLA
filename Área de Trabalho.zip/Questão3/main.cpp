#include <iostream>
#include "filaenc.hpp"
using namespace std;

int main(){
	FilaEnc* fila = criar_fila();
	inserir(fila,1);
	inserir(fila,2);
	inserir(fila,3);
	inserir(fila,5);
	
	inserir_ordenado(fila,6);
	imprimir(fila);
}
