#ifndef FILAENC_HPP
#define FILAENC_HPP

/** 
 * Declaração opaca da estrutura de uma fila.
 * 
 * Isso significa que os detalhes de implementação desta estrutura estão escondidos do usuário do TAD. 
 * A definição da estrutura FilaEnc encontra-se no arquivo \file FilaEnc.cpp.
 */
struct FilaEnc;

/** 
 * Declaração opaca da estrutura de um nó da fila.
 * 
 * Isso significa que os detalhes de implementação desta estrutura estão escondidos do usuário do TAD. 
 * A definição da estrutura Noh encontra-se no arquivo \file filaenc.cpp.
 */
struct Noh;

// Cria dinamicamente uma fila vazia e retorna o endereço onde ela se encontra alocada.
FilaEnc* criar_fila();

// Libera o espaço de memória anteriormente reservado para a fila.
void liberar_fila(FilaEnc* f);

// Verifica se a fila está vazia. 
bool estah_vazia(FilaEnc* f);

// Insere um novo elemento no final da fila.  
void inserir(FilaEnc* f, int item);

// Remove e retorna o elemento do início da fila. 
int remover(FilaEnc* f);

// Apenas retorna o elemento do início da fila. 
int obter_inicio(FilaEnc* f);

void inserir_ordenado(FilaEnc* fila,int item);

void imprimir(FilaEnc* fila);

#endif
