#ifndef PILHAENC_HPP
#define PILHAENC_HPP

/** 
 * Declaração opaca da estrutura de uma pilha.
 * 
 * Isso significa que os detalhes de implementação desta estrutura estão escondidos do usuário do TAD. 
 * A definição da estrutura PilhaEnc encontra-se no arquivo \file pilhaenc.cpp.
 */
struct PilhaEnc;

/** 
 * Declaração opaca da estrutura de um nó da pilha.
 * 
 * Isso significa que os detalhes de implementação desta estrutura estão escondidos do usuário do TAD. 
 * A definição da estrutura Noh encontra-se no arquivo \file pilhaenc.cpp.
 */
struct Noh;

// Cria dinamicamente uma pilha vazia e retorna o endereço onde ela se encontra alocada.
PilhaEnc* criar_pilha();

// Libera o espaço de memória anteriormente reservado para a pilha.
void liberar_pilha(PilhaEnc* p);

// Verifica se a pilha está vazia. 
bool estah_vazia(PilhaEnc* p);

// Insere um novo elemento na pilha.  
void empilhar(PilhaEnc* p, int item);

// Remove e retorna o elemento do topo da pilha. 
int desempilhar(PilhaEnc* p);

// Apenas retorna o elemento do topo da pilha. 
int obter_topo(PilhaEnc* p);

int* vetor_pilha(PilhaEnc* pilha);
#endif
