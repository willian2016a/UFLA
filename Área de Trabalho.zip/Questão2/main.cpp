#include <iostream>
#include "pilhaenc.hpp"

using namespace std;

int main(){
	PilhaEnc* pilha = criar_pilha();
	for(int i=0;i<5;i++){
		int num;
		cin>>num;
		empilhar(pilha,num);
	}
	int *vetor = vetor_pilha(pilha);
	for(int k=0;k<5;k++){
		cout<<vetor[k]<<" ";
	}
}
