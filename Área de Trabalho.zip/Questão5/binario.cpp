#include <iostream>
using namespace std;

bool binario(int v[],int n,int item){
	bool conf=false;
	int inicio=0;
	int fim = n-1;
	int iteracao = 1;
	while(inicio<=fim){
		int meio = ((inicio+fim)/2);
		if(v[meio] == item){
			int qtd = (fim-meio)+(meio-inicio);
			cout<<"Iteração "<<iteracao<<": "<<qtd;
			inicio = fim + 1;
			conf = true;
		}else if(v[meio] > item){
			int qtd = fim-meio+1;
			cout<<"Iteração "<<iteracao<<": "<<qtd;
			cout<<endl;
			fim = meio-1;
			iteracao++;
		}else{
			int qtd = meio-inicio+1;
			cout<<"Iteração "<<iteracao<<": "<<qtd;
			cout<<endl;
			inicio = meio+1;
			iteracao++;
		}
	}
	
	return conf;
}
int main(){
	
	int n;
	cin>>n;
	int v[n];
	for (int i=0;i<n;i++){
		cin>>v[i];
	}
	int item;
	cin>>item;
	
	bool conf = binario(v,n,item);
	cout<<endl;
	cout<<conf;
}
