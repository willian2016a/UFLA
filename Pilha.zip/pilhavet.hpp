#ifndef PILHAVET_HPP
#define PILHAVET_HPP

#define TAM_MAX 100
#include <iostream>
#include <cassert>

using namespace std;
struct PilhaVet;

PilhaVet* criar_pilha();

void liberar_pilha(PilhaVet* pilha);

bool estah_vazia(PilhaVet* pilha);

bool estah_cheia(PilhaVet* pilha);

void empilhar(PilhaVet* pilha, int item);

int desempilhar(PilhaVet* pilha);

int obter_topo(PilhaVet* pilha);

#endif
