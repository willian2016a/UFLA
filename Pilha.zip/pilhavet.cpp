#include "pilhavet.hpp"
#include <cassert>
#include <iostream>
struct PilhaVet{
	int itens[TAM_MAX];
	int topo;
};

 PilhaVet* criar_pilha(){
	PilhaVet* pilha = new PilhaVet;
	pilha->topo = 0;
	return pilha;
}

void liberar_pilha(PilhaVet* pilha){
	assert(pilha != NULL);
	delete pilha;
}

bool estah_vazia(PilhaVet* pilha){
	assert(pilha != NULL);
	return (pilha->topo == 0);
}

bool estah_cheia(PilhaVet* pilha){
	assert(pilha != NULL);
	return (pilha->topo == TAM_MAX);
}

void empilhar(PilhaVet* pilha, int item){
	assert(pilha != NULL);
	assert(pilha->topo != TAM_MAX);
	pilha->itens[pilha->topo] = item;
	pilha->topo ++;
}

int desempilhar(PilhaVet* pilha){
	assert(pilha != NULL);
	assert(pilha->topo != 0);
	int item = pilha->itens[pilha->topo - 1];
	pilha->topo--;
	return item;
}

int obter_topo(PilhaVet* pilha){
	assert(pilha != NULL);
	assert(pilha->topo != 0);
	return (pilha->itens[pilha->topo -1]);
}
